# 一堂画布 0.2.8 维护源码

作者：尹白猿。此快照与公共应用源的 0.2.8 执行包对应。包含应用源码、锁文件、原创图标和虚构测试，不包含 KSF 实例数据、课程原件、浏览器草稿或 SDK 源码。

开发时取得 KSF SDK 1.1.0 开发包，放在 app/ 相邻的 sdk/ 目录；使用 Node.js 24，在 app/ 执行 npm ci --ignore-scripts、npm run typecheck、npm test、npm run check、npm run build。

本次公开分发依据应用作者的明确发布请求；未新增通用开源许可证。KSF SDK 及第三方组件分别遵循原始授权与执行包内 THIRD_PARTY_NOTICES.txt。
