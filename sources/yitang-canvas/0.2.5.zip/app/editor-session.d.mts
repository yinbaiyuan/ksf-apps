import type {Canvas} from './types';
export class EditorSession {
  record:Canvas; saved:Canvas; dirty:boolean; status:string; error:string; conflict:Canvas|null; draftWarning?:string;
  constructor(options:{record:Canvas;write:(p:Canvas & {operationId:string})=>Promise<Canvas>;read:(id:string)=>Promise<Canvas>;persist?:(draft:{record:Canvas;baseRevision:number})=>void;clear?:()=>void;notify?:(s:EditorSession)=>void;delay?:number});
  edit(action:(c:Canvas)=>Canvas):void;restore(draft:{record:Canvas;baseRevision:number}):void;flush():Promise<void>;remember():void;useSaved():void;dispose():void;
}
