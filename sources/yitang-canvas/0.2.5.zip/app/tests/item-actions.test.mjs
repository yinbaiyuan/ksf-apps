import {test} from 'node:test';
import assert from 'node:assert/strict';
import {insertItemAfter,reorderItems,wantsNewItem} from '../item-actions.mjs';
test('Shift+Enter 新增；普通回车、输入法确认、组合修饰键和长按不新增',()=>{
 const event={key:'Enter',shiftKey:true};assert.equal(wantsNewItem(event),true);
 for(const change of [{shiftKey:false},{isComposing:true},{keyCode:229},{repeat:true},{ctrlKey:true},{metaKey:true},{altKey:true},{key:'a'}])assert.equal(wantsNewItem({...event,...change}),false);
 assert.equal(wantsNewItem(event,true),false);
});
test('从中间与最后一条插入，只增加空条目，原条目和全文保持不变',()=>{
 const source=[{id:'a',text:'甲\n乙'},{id:'b',text:'数字 123'}],snapshot=structuredClone(source),item={id:'new',text:''};
 assert.deepEqual(insertItemAfter(source,'a',item).map(i=>i.id),['a','new','b']);assert.deepEqual(insertItemAfter(source,'b',item).map(i=>i.id),['a','b','new']);assert.deepEqual(source,snapshot);
 assert.deepEqual(insertItemAfter([],null,item),[item]);assert.equal(insertItemAfter(source,'unknown',item),source);
});
test('拖动到首部、中间、尾部保持身份、文字和条目数量；无效或原位拖动不改变顺序',()=>{
 const items=['a','b','c','d'].map(id=>({id,text:id+'的多行内容\n123'})),original=structuredClone(items);
 assert.deepEqual(reorderItems(items,'d','a','before').map(i=>i.id),['d','a','b','c']);
 assert.deepEqual(reorderItems(items,'a','c','after').map(i=>i.id),['b','c','a','d']);
 assert.deepEqual(reorderItems(items,'b','d','after').map(i=>i.id),['a','c','d','b']);
 const next=reorderItems(items,'d','b','before');assert.deepEqual([...next].sort((a,b)=>a.id.localeCompare(b.id)),original);assert.deepEqual(items,original);
 assert.equal(reorderItems(items,'b','b','after'),items);assert.equal(reorderItems(items,'b','a','after'),items);assert.equal(reorderItems(items,'x','a'),items);
});
