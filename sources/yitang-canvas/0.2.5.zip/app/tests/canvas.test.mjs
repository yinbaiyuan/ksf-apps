import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,writeFile,readFile,readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {activate} from '../backend.mjs';
import {blankCanvas,uid,validCanvas} from '../model.mjs';
import {templates} from '../templates.mjs';
import {EditorSession} from '../editor-session.mjs';
async function fixture(t){const root=await mkdtemp(join(tmpdir(),'yitang-canvas-'));t.after(()=>rm(root,{recursive:true,force:true}));const context={dataDirectory:root,appId:'com.yinbaiyuan.yitang-canvas',services:{call:async()=>{throw Error('unavailable');}}};return {root,context,backend:activate(context)};}
const create=(backend,templateId='five-step',extra={})=>backend.call('canvas.create',{id:uid(),title:'验收画布',templateId,operationId:uid(),...extra});
test('原图的五步法九区域与双三角六区域，空白、稳定条目、可分别保存',async t=>{
 const {backend,root}=await fixture(t);assert.deepEqual((await backend.call('canvas.list')).canvases,[]);assert.deepEqual(await readdir(root),[]);
 assert.deepEqual(templates[0].columns.map(c=>c.title),['我的业务','需求','解决方案','商业模式','增长','壁垒']);assert.deepEqual(templates[1].regions.map(r=>r.title),['场景','审美','体系','数据','基本功','创造力']);
 for(const template of templates){const {canvas}=await create(backend,template.id);assert.equal(Object.keys(canvas.regions).length,template.regions.length);assert.ok(Object.values(canvas.regions).flat().every(i=>i.text===''));assert.equal(validCanvas(canvas),true);assert.deepEqual((await backend.call('canvas.read',{id:canvas.id})).canvas,canvas);}
 assert.equal((await backend.call('canvas.list')).canvases.length,2);
});
test('增删、排序、项目、改名、归档恢复、复制独立及真实存储重开',async t=>{
 const {backend,context}=await fixture(t);let {canvas}=await create(backend);const one=canvas.regions.users[0].id,two=uid();
 canvas=(await backend.call('canvas.update',{...canvas,title:'新名字',project:{name:'示例',path:'项目/示例/project.md'},regions:{...canvas.regions,users:[{id:two,text:'第二条\n多行内容 123'},{id:one,text:'第一条'}]},operationId:uid()})).canvas;
 assert.equal(canvas.regions.users[1].id,one);assert.equal(canvas.revision,2);
 let copy=(await create(backend,canvas.templateId,{title:'副本',sourceId:canvas.id})).canvas;assert.notEqual(copy.regions.users[0].id,two);assert.equal(copy.regions.users[0].text,'第二条\n多行内容 123');
 canvas=(await backend.call('canvas.update',{...canvas,archived:true,operationId:uid()})).canvas;assert.equal(canvas.archived,true);canvas=(await backend.call('canvas.update',{...canvas,archived:false,operationId:uid()})).canvas;
 assert.deepEqual((await activate(context).call('canvas.read',{id:canvas.id})).canvas,canvas);assert.equal(copy.project,null);
});
test('并发拒绝覆盖，丢失回执可对账，重复操作不重复创建，非法内容不落盘',async t=>{
 const {backend,root}=await fixture(t);const payload={id:uid(),title:'幂等',templateId:'five-step',operationId:uid()};const {canvas}=await backend.call('canvas.create',payload);await backend.call('canvas.create',payload);assert.equal((await backend.call('canvas.list')).canvases.length,1);
 const request={...canvas,title:'成功修改',operationId:uid()};const updated=(await backend.call('canvas.update',request)).canvas;assert.deepEqual((await backend.call('canvas.update',request)).canvas,updated);
 await assert.rejects(backend.call('canvas.update',{...canvas,title:'旧版本覆盖',operationId:uid()}),{code:'APP_DATA_CONFLICT'});
 const before=await readFile(join(root,'canvases.json'),'utf8');await assert.rejects(backend.call('canvas.update',{...updated,regions:{},operationId:uid()}),{code:'CANVAS_INVALID'});assert.equal(await readFile(join(root,'canvases.json'),'utf8'),before);
});
test('Markdown 转义和 JSON 备份保真；项目不可访问时可独立使用',async t=>{
 const {backend}=await fixture(t);let {canvas}=await create(backend,'double-triangle');canvas.regions.scenario[0].text='甲 | 乙\n<script>alert(1)</script>';canvas=(await backend.call('canvas.update',{...canvas,operationId:uid()})).canvas;
 const md=await backend.call('canvas.export',{id:canvas.id});assert.match(md.text,/&#124;/);assert.match(md.text,/&lt;script&gt;/);assert.match(md.text,/场景 \| 审美 \| 体系/);
 const json=await backend.call('canvas.export',{id:canvas.id,format:'json'});assert.deepEqual(JSON.parse(json.text).canvas,canvas);assert.ok((await backend.call('projects.list')).warning);
});
test('损坏和较新格式保留原件，不写入空状态',async t=>{
 const {backend,root}=await fixture(t),file=join(root,'canvases.json');for(const original of ['{broken',JSON.stringify({schemaVersion:99,revision:1,data:{canvases:[]}})]){await writeFile(file,original);await assert.rejects(backend.call('canvas.list'));await assert.rejects(create(backend));assert.equal(await readFile(file,'utf8'),original);}
});
function sessionFixture(t,options={}){let disk=blankCanvas({id:uid(),title:'编辑',templateId:'five-step'},uid,new Date().toISOString()),draft=null,writes=0;const s=new EditorSession({record:disk,delay:60000,persist:d=>{draft=structuredClone(d);},clear:()=>{draft=null;},read:async()=>structuredClone(disk),write:async p=>{writes++;disk={...p,revision:disk.revision+1,lastOperation:{id:p.operationId}};return structuredClone(disk);},...options});t.after(()=>s.dispose());return {s,getDisk:()=>disk,setDisk:d=>{disk=d;},draft:()=>draft,writes:()=>writes};}
test('保存中的新输入不会被旧响应覆盖，全部写入后才清除草稿',async t=>{
 let release,entered;const started=new Promise(r=>entered=r),gate=new Promise(r=>release=r);let n=0;
 const f=sessionFixture(t,{write:async p=>{if(++n===1){entered();await gate;}return {...p,revision:p.revision+1};}});
 f.s.edit(c=>({...c,title:'第一轮'}));const save=f.s.flush();await started;f.s.edit(c=>({...c,title:'正在保存时继续输入'}));release();await save;assert.equal(n,2);assert.equal(f.s.record.title,'正在保存时继续输入');assert.equal(f.s.saved.revision,3);assert.equal(f.s.dirty,false);assert.equal(f.draft(),null);
});
test('保存失败保留草稿和 dirty；服务端已提交但响应丢失时先读回对账',async t=>{
 const f=sessionFixture(t,{write:async()=>{throw Error('离线');}});f.s.edit(c=>({...c,title:'不能丢失'}));await assert.rejects(f.s.flush(),/离线/);assert.equal(f.s.dirty,true);assert.equal(f.draft().record.title,'不能丢失');
 const g=sessionFixture(t);g.s.write=async p=>{g.setDisk({...p,revision:2,lastOperation:{id:p.operationId}});throw Error('响应丢失');};g.s.edit(c=>({...c,title:'已经提交'}));await g.s.flush();assert.equal(g.s.status,'saved');assert.equal(g.s.record.title,'已经提交');
});
test('恢复草稿遇到新版本时暂停保存，核对前绝不覆盖远端',async t=>{
 const f=sessionFixture(t),draft={record:{...f.s.record,title:'离线草稿'},baseRevision:0};f.s.restore(draft);assert.equal(f.s.status,'conflict');await assert.rejects(f.s.flush());assert.equal(f.writes(),0);assert.equal(f.s.record.title,'离线草稿');f.s.useSaved();assert.equal(f.s.record.title,'编辑');assert.equal(f.s.dirty,false);
});
