export type Item={id:string;text:string};
export type Project={name:string;path:string};
export type Canvas={id:string;title:string;templateId:string;templateVersion:number;project:Project|null;archived:boolean;revision:number;createdAt:string;updatedAt:string;regions:Record<string,Item[]>;lastOperation?:{id:string;digest:string}};
export type Summary=Omit<Canvas,'regions'> & {preview:string};
export type Template={id:string;version:number;name:string;shortName:string;description:string;columns?:{title:string;regions:string[]}[];regions:{id:string;title:string;hint:string;triangle?:'human'|'ai';negative?:boolean}[]};
