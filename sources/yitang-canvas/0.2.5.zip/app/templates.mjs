export const templates = [
  {id:'five-step',version:1,name:'五步法·基础取舍版',shortName:'五步法',description:'从需求到壁垒，理清业务的关键取舍。',columns:[
    {title:'我的业务',regions:['business']}, {title:'需求',regions:['users','non-users']},
    {title:'解决方案',regions:['core','non-core']}, {title:'商业模式',regions:['unit-model']},
    {title:'增长',regions:['growth']}, {title:'壁垒',regions:['barriers','non-barriers']}
  ],regions:[
    {id:'business',title:'我的业务',hint:'用几句话说明：正在做什么业务，为谁创造什么价值？'},
    {id:'users',title:'用户',hint:'具体写出核心用户、发生问题的场景与痛点。先选最重要的人群。'},
    {id:'non-users',title:'非用户',hint:'明确当前不服务哪些人，避免把所有人都当作用户。',negative:true},
    {id:'core',title:'内核',hint:'哪些价值一旦拿掉，用户就不再选择你？写下最关键的要素。'},
    {id:'non-core',title:'非内核',hint:'哪些功能或服务可以暂缓、舍弃，或交给其他方式完成？',negative:true},
    {id:'unit-model',title:'单元模型',hint:'选择需要反复复制的单元，如一单、一位客户或一家门店；写清如何赚钱。可直接填写数字。'},
    {id:'growth',title:'增长',hint:'写清第一指标、优先渠道与复制方式，也可记录暂缓的增长选项。'},
    {id:'barriers',title:'壁垒',hint:'面对长期竞争，什么优势会持续积累？说明优势来源及强弱。'},
    {id:'non-barriers',title:'非壁垒',hint:'哪些看起来是优势，却容易被模仿，或暂时不能构成壁垒？',negative:true}
  ]},
  {id:'double-triangle',version:1,name:'一堂双三角',shortName:'双三角',description:'把一个 AI 场景的六个要素放到同一张画布。',regions:[
    {id:'scenario',triangle:'ai',title:'场景',hint:'谁在什么情况下，要完成什么任务？希望产出什么结果？'},
    {id:'taste',triangle:'human',title:'审美',hint:'什么样的结果才算好？写下判断标准、优秀样例和不能接受的问题。'},
    {id:'system',triangle:'human',title:'体系',hint:'完成任务有哪些步骤、方法、知识和工作流？哪些环节由人判断？'},
    {id:'data',triangle:'ai',title:'数据',hint:'需要哪些事实、材料、案例和数据？记录已有资料与仍需补充的内容。'},
    {id:'skills',triangle:'ai',title:'基本功',hint:'需要哪些 AI 工具、提示词、操作和调试能力？逐条记录。'},
    {id:'creativity',triangle:'human',title:'创造力',hint:'有哪些值得尝试的新组合、新解法或突破方向？先把想法记下来。'}
  ]}
];
export function templateFor(id){return templates.find(t=>t.id===id);}
