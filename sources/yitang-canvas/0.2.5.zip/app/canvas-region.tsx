import {useEffect,useId,useLayoutEffect,useRef,useState,type PointerEvent} from 'react';
import {ArrowDown,ArrowUp,GripVertical,HelpCircle,MoreHorizontal,Plus,Trash2} from 'lucide-react';
import {uid} from './model.mjs';
import {insertItemAfter,reorderItems,wantsNewItem} from './item-actions.mjs';
import type {Item,Template} from './types';

type Drop={id:string;side:'before'|'after'};
type Gesture={id:string;pointerId:number;handle:HTMLButtonElement;startY:number;startScroll:number;maxScroll:number;x:number;y:number;started:boolean;drop:Drop|null;scroller:HTMLElement|null};
type Region=Template['regions'][number];
type Props={region:Region;items:Item[];disabled:boolean;hints:boolean;onItemsChange:(action:(items:Item[])=>Item[])=>void;onDelete:(item:Item,index:number)=>void};

function TextRow({item,index,total,label,disabled,dragging,offset,drop,onText,onMove,onDelete,onInsert,onPointerDown,onPointerMove,onPointerUp,onCancel}:{item:Item;index:number;total:number;label:string;disabled:boolean;dragging:boolean;offset:number;drop:Drop|null;onText:(text:string)=>void;onMove:(direction:number)=>void;onDelete:()=>void;onInsert:()=>void;onPointerDown:(event:PointerEvent<HTMLButtonElement>)=>void;onPointerMove:(event:PointerEvent<HTMLButtonElement>)=>void;onPointerUp:()=>void;onCancel:()=>void}){
  const input=useRef<HTMLTextAreaElement>(null),composing=useRef(false);
  useLayoutEffect(()=>{const el=input.current;if(!el)return;let width=-1;const fit=()=>{el.style.height='auto';el.style.height=Math.max(34,el.scrollHeight+2)+'px';};fit();const observer=new ResizeObserver(entries=>{const next=entries[0].contentRect.width;if(next!==width){width=next;fit();}});observer.observe(el);return()=>observer.disconnect();},[item.text]);
  const closeMenu=(button:HTMLButtonElement)=>button.closest('details')?.removeAttribute('open');
  return <div data-item-id={item.id} className={'yc-row'+(dragging?' is-dragging':'')+(drop?.id===item.id?' yc-drop-'+drop.side:'')} style={dragging?{transform:`translateY(${offset}px)`}:undefined}>
    <div className="yc-row-gutter"><span className="yc-number">{String(index+1).padStart(2,'0')}</span>{!disabled&&<button className="yc-grip" aria-label={`拖动${label}第${index+1}条排序`} title="拖动排序，也可按 ↑ ↓ 移动" onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerCancel={onCancel} onLostPointerCapture={onCancel} onKeyDown={e=>{if(e.key==='Escape'){e.preventDefault();onCancel();}if((e.key==='ArrowUp'||e.key==='ArrowDown')&&!e.nativeEvent.isComposing){e.preventDefault();const direction=e.key==='ArrowUp'?-1:1;if(index+direction>=0&&index+direction<total)onMove(direction);}}}><GripVertical size={15}/></button>}</div>
    <textarea ref={input} aria-label={`${label}第${index+1}条`} value={item.text} disabled={disabled} placeholder="写下你的思考…" rows={1} onChange={e=>onText(e.target.value)} onCompositionStart={()=>{composing.current=true;}} onCompositionEnd={()=>{composing.current=false;}} onKeyDown={e=>{if(!disabled&&wantsNewItem(e.nativeEvent,composing.current)){e.preventDefault();e.stopPropagation();onInsert();}}}/>
    {!disabled&&<details className="yc-row-menu" onBlur={e=>{if(!e.currentTarget.contains(e.relatedTarget as Node|null))e.currentTarget.removeAttribute('open');}} onKeyDown={e=>{if(e.key==='Escape'){e.preventDefault();e.currentTarget.removeAttribute('open');e.currentTarget.querySelector('summary')?.focus();}}}>
      <summary aria-label={`${label}第${index+1}条的更多操作`} title="条目操作"><MoreHorizontal size={16}/></summary>
      <div className="yc-row-actions"><button aria-label={`上移${label}第${index+1}条`} title="上移" disabled={index===0} onClick={e=>{closeMenu(e.currentTarget);onMove(-1);}}><ArrowUp size={14}/></button><button aria-label={`下移${label}第${index+1}条`} title="下移" disabled={index===total-1} onClick={e=>{closeMenu(e.currentTarget);onMove(1);}}><ArrowDown size={14}/></button><button aria-label={`删除${label}第${index+1}条`} title="删除条目" onClick={e=>{closeMenu(e.currentTarget);onDelete();}}><Trash2 size={14}/></button></div>
    </details>}
  </div>;
}

export function CanvasRegion({region,items,disabled,hints,onItemsChange,onDelete}:Props){
  const root=useRef<HTMLElement>(null),gesture=useRef<Gesture|null>(null),frame=useRef(0),latest=useRef(items),[focusId,setFocusId]=useState<string|null>(null),[drag,setDrag]=useState<{id:string;offset:number}|null>(null),[drop,setDrop]=useState<Drop|null>(null),[announcement,setAnnouncement]=useState('');
  const hintId=useId();latest.current=items;
  function release(){const d=gesture.current;gesture.current=null;cancelAnimationFrame(frame.current);if(d?.handle.hasPointerCapture(d.pointerId))d.handle.releasePointerCapture(d.pointerId);}
  function cancel(){release();setDrag(null);setDrop(null);}
  useEffect(()=>{const blur=()=>cancel();window.addEventListener('blur',blur);return()=>{release();window.removeEventListener('blur',blur);};},[]);
  useEffect(()=>{if(disabled)cancel();},[disabled]);
  useLayoutEffect(()=>{if(!focusId)return;const el=Array.from(root.current?.querySelectorAll<HTMLTextAreaElement>('.yc-row textarea')??[]).find(el=>el.closest<HTMLElement>('[data-item-id]')?.dataset.itemId===focusId);if(el){el.focus({preventScroll:true});el.scrollIntoView({block:'nearest',inline:'nearest'});setFocusId(null);}},[focusId,items]);
  function insert(sourceId:string|null){const item={id:uid(),text:''};setFocusId(item.id);onItemsChange(current=>insertItemAfter(current,sourceId,item));}
  function track(){
    const d=gesture.current,r=root.current;if(!d||!r)return;
    const bounds=r.getBoundingClientRect(),scroll=d.scroller?.getBoundingClientRect();
    const inside=d.x>=bounds.left&&d.x<=bounds.right&&d.y>=Math.max(bounds.top,scroll?.top??bounds.top)&&d.y<=Math.min(bounds.bottom,scroll?.bottom??bounds.bottom);
    const targets=Array.from(r.querySelectorAll<HTMLElement>('.yc-row')).filter(el=>el.dataset.itemId!==d.id);
    let target:Drop|null=null;
    if(inside&&targets.length){const before=targets.find(el=>{const box=el.getBoundingClientRect();return d.y<box.top+box.height/2;});target=before?{id:before.dataset.itemId!,side:'before'}:{id:targets.at(-1)!.dataset.itemId!,side:'after'};}
    d.drop=target;setDrop(target);setDrag({id:d.id,offset:d.y-d.startY+(d.scroller?.scrollTop??0)-d.startScroll});
  }
  function autoScroll(){const d=gesture.current;if(!d?.started)return;if(d.scroller){const bounds=d.scroller.getBoundingClientRect(),before=d.scroller.scrollTop;const speed=d.y>=bounds.top&&d.y<bounds.top+36?-12:d.y<=bounds.bottom&&d.y>bounds.bottom-36?12:0;if(speed)d.scroller.scrollTop=Math.max(0,Math.min(d.maxScroll,before+speed));if(d.scroller.scrollTop!==before)track();}frame.current=requestAnimationFrame(autoScroll);}
  function begin(event:PointerEvent<HTMLButtonElement>,id:string){if(disabled||event.button!==0)return;event.preventDefault();event.stopPropagation();event.currentTarget.focus({preventScroll:true});event.currentTarget.setPointerCapture(event.pointerId);const scroller=root.current?.closest<HTMLElement>('.yc-canvas-scroll')??null;gesture.current={id,pointerId:event.pointerId,handle:event.currentTarget,startY:event.clientY,startScroll:scroller?.scrollTop??0,maxScroll:scroller?scroller.scrollHeight-scroller.clientHeight:0,x:event.clientX,y:event.clientY,started:false,drop:null,scroller};}
  function move(event:PointerEvent<HTMLButtonElement>){const d=gesture.current;if(!d||event.pointerId!==d.pointerId)return;d.x=event.clientX;d.y=event.clientY;if(!d.started){if(Math.abs(d.y-d.startY)<5)return;d.started=true;frame.current=requestAnimationFrame(autoScroll);}event.preventDefault();track();}
  function finish(){const d=gesture.current;if(!d)return;const target=d.drop;release();setDrag(null);setDrop(null);if(d.started&&target){const current=latest.current,next=reorderItems(current,d.id,target.id,target.side);if(next!==current){onItemsChange(items=>reorderItems(items,d.id,target.id,target.side));setAnnouncement(`已移到${region.title}第${next.findIndex(i=>i.id===d.id)+1}条。`);}}}
  return <section ref={root} data-region-id={region.id} className={'yc-region'+(region.negative?' yc-negative':'')+(drag?' yc-sorting':'')} aria-label={region.title}>
    <div className="yc-region-title"><h3>{region.title}</h3>{region.triangle&&<span className="yc-triangle-label">{region.triangle==='human'?'人类三角':'AI 三角'}</span>}{hints&&<HelpCircle size={14}/>}</div>{hints&&<p id={hintId} className="yc-hint">{region.hint}</p>}
    <div className="yc-items">{items.map((item,index)=><TextRow key={item.id} item={item} index={index} total={items.length} label={region.title} disabled={disabled} dragging={drag?.id===item.id} offset={drag?.offset??0} drop={drop} onText={text=>onItemsChange(items=>items.map(i=>i.id===item.id?{...i,text}:i))} onMove={direction=>{const target=latest.current[index+direction];if(target)onItemsChange(items=>reorderItems(items,item.id,target.id,direction<0?'before':'after'));}} onDelete={()=>onDelete(item,index)} onInsert={()=>insert(item.id)} onPointerDown={e=>begin(e,item.id)} onPointerMove={move} onPointerUp={finish} onCancel={cancel}/>)}</div>
    {!disabled&&<button className="yc-add-row" onClick={()=>insert(null)}><Plus size={14}/>添加一条<span className="yc-sr">{region.title}</span></button>}
    <span className="yc-sr" role="status" aria-live="polite">{announcement}</span>
  </section>;
}
