import {templateFor} from './templates.mjs';
export const clone=value=>structuredClone(value);
export const uid=()=>Array.from(globalThis.crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');
export const fail=(code,message)=>{throw Object.assign(new Error(message),{code});};
const plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const id=v=>typeof v==='string'&&/^[a-zA-Z0-9_-]{1,100}$/.test(v);
export function validProject(p){return p===null||(plain(p)&&typeof p.name==='string'&&p.name.length<=200&&typeof p.path==='string'&&/^项目\/[^/\\]+\/project\.md$/.test(p.path)&&!p.path.includes('..'));}
export function validCanvas(c){
  if(!plain(c)||!id(c.id)||typeof c.title!=='string'||!c.title.trim()||c.title.length>200||!validProject(c.project)||typeof c.archived!=='boolean'||!Number.isSafeInteger(c.revision)||c.revision<1||typeof c.createdAt!=='string'||typeof c.updatedAt!=='string')return false;
  const t=templateFor(c.templateId);if(!t||c.templateVersion!==t.version||!plain(c.regions)||Object.keys(c.regions).length!==t.regions.length)return false;
  const ids=new Set();for(const r of t.regions){const items=c.regions[r.id];if(!Array.isArray(items)||items.length>500)return false;for(const item of items){if(!plain(item)||!id(item.id)||ids.has(item.id)||typeof item.text!=='string'||item.text.length>50000)return false;ids.add(item.id);}}
  return !c.lastOperation||(plain(c.lastOperation)&&id(c.lastOperation.id)&&typeof c.lastOperation.digest==='string');
}
export function validState(s){return plain(s)&&Array.isArray(s.canvases)&&s.canvases.length<=1000&&s.canvases.every(validCanvas)&&new Set(s.canvases.map(c=>c.id)).size===s.canvases.length;}
export function blankCanvas({id,title,templateId,project=null},newId,now){
  const t=templateFor(templateId);if(!t)fail('CANVAS_TEMPLATE_INVALID','请选择五步法或双三角模板。');
  const c={id,title:title?.trim(),templateId,templateVersion:t.version,project,archived:false,revision:1,createdAt:now,updatedAt:now,regions:Object.fromEntries(t.regions.map(r=>[r.id,[{id:newId(),text:''}]]))};
  if(!validCanvas(c))fail('CANVAS_INVALID','画布名称、项目或内容格式不正确。');return c;
}
export function markdown(c){
  const t=templateFor(c.templateId),escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('|','&#124;').replaceAll('\r','').replaceAll('\n','<br>');
  const section=r=>`**${r.title}**<br>`+c.regions[r.id].filter(i=>i.text.trim()).map((i,n)=>`${n+1}. ${escape(i.text)}`).join('<br><br>');
  const table=(heads,cells)=>`| ${heads.join(' | ')} |\n| ${heads.map(()=>'---').join(' | ')} |\n| ${cells.join(' | ')} |\n`;
  let out=`# ${c.title.replaceAll('\n',' ')}\n\n${t.name}\n\n`+(c.project?`关联项目：${c.project.name}\n\n`:'');
  if(t.columns)out+=table(t.columns.map(x=>x.title),t.columns.map(x=>x.regions.map(id=>section(t.regions.find(r=>r.id===id))).join('<br><br>')));
  else for(let n=0;n<6;n+=3)out+=table(t.regions.slice(n,n+3).map(r=>r.title),t.regions.slice(n,n+3).map(r=>c.regions[r.id].filter(i=>i.text.trim()).map((i,n)=>`${n+1}. ${escape(i.text)}`).join('<br><br>')))+'\n';
  return out;
}
