import {createJSONStore} from '@ksf/sdk/storage';
import {randomUUID,createHash} from 'node:crypto';
import {templates,templateFor} from './templates.mjs';
import {blankCanvas,clone,fail,validState,validCanvas,validProject,markdown} from './model.mjs';
const storeFor=context=>createJSONStore(context,{name:'canvases.json',scope:'user',schemaVersion:1,initial:{canvases:[]},validate:validState});
const digest=p=>createHash('sha256').update(JSON.stringify(p)).digest('hex');
export async function prepareData(context){await storeFor(context).migrate();}
export function activate(context){
  const store=storeFor(context);
  const find=(state,id)=>state.canvases.find(c=>c.id===id)??fail('CANVAS_NOT_FOUND','画布不存在，请返回列表重新选择。');
  async function write(method,p){
    if(!p||typeof p.operationId!=='string'||!/^[a-zA-Z0-9_-]{1,100}$/.test(p.operationId))fail('CANVAS_INVALID','写入缺少有效的操作编号。');
    const fingerprint=digest({method,...p});let result;
    await store.update(state=>{
      const previous=state.canvases.find(c=>c.id===p.id);
      if(previous?.lastOperation?.id===p.operationId){if(previous.lastOperation.digest!==fingerprint)fail('CANVAS_OPERATION_CONFLICT','同一次操作的内容不一致，请重新核对。');result=previous;return state;}
      let next;
      if(method==='canvas.create'){
        if(previous)fail('CANVAS_EXISTS','此画布已存在，请重新读取。');
        next=blankCanvas(p,randomUUID,new Date().toISOString());
        if(p.sourceId){const source=find(state,p.sourceId);next.regions=Object.fromEntries(Object.entries(source.regions).map(([key,items])=>[key,items.map(i=>({id:randomUUID(),text:i.text}))]));if(source.templateId!==next.templateId)fail('CANVAS_TEMPLATE_INVALID','复制画布的模板不一致。');}
        state.canvases.push(next);
      }else{
        const current=find(state,p.id);
        if(p.revision!==current.revision)fail('APP_DATA_CONFLICT','画布已有其他修改，当前草稿已保留。请核对已保存版本，或将草稿另存为副本。');
        next={...current,title:p.title?.trim(),project:p.project,regions:clone(p.regions),archived:p.archived,revision:current.revision+1,updatedAt:new Date().toISOString()};
        state.canvases[state.canvases.indexOf(current)]=next;
      }
      next.lastOperation={id:p.operationId,digest:fingerprint};
      if(!validCanvas(next)||Buffer.byteLength(JSON.stringify(next))>700000)fail('CANVAS_INVALID','画布内容过大或格式不正确，草稿已保留。单条最多 5 万字，单份画布最多约 700 KB。');
      result=next;return state;
    });
    return {canvas:result};
  }
  return {async call(method,p={}){
    if(method==='templates')return {templates};
    if(method==='canvas.list')return {canvases:(await store.read()).data.canvases.map(({regions,lastOperation,...c})=>({...c,preview:Object.values(regions).flat().map(i=>i.text).join(' ').slice(0,160)}))};
    if(method==='canvas.read')return {canvas:find((await store.read()).data,p.id)};
    if(['canvas.create','canvas.update'].includes(method))return write(method,p);
    if(method==='canvas.export'){
      const c=find((await store.read()).data,p.id),json=p.format==='json';
      return {name:c.title.replace(/[\\/:*?"<>|\x00-\x1f]/g,'-')+(json?'.json':'.md'),mime:json?'application/json':'text/markdown',text:json?JSON.stringify({format:'yitang-canvas-backup',schemaVersion:1,exportedAt:new Date().toISOString(),canvas:c},null,2):markdown(c)};
    }
    if(method==='projects.list'){
      try{const tree=await context.services.call('workspace','tree',['项目']);const rows=await Promise.all(tree.entries.filter(e=>e.kind==='directory').map(async e=>{try{const child=await context.services.call('workspace','tree',[e.path]);return child.entries.some(f=>f.name==='project.md'&&f.kind==='file')?{name:e.name,path:e.path+'/project.md'}:null;}catch{return null;}}));return {projects:rows.filter(Boolean),warning:null};}
      catch{return {projects:[],warning:'暂时无法读取项目列表；你可以继续独立填写画布。'};}
    }
    fail('APP_METHOD_UNKNOWN','未知的应用操作。');
  }};
}
