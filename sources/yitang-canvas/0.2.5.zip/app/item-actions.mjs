// Reordering never changes content or identity, and accepts only existing row IDs.
export function reorderItems(items,sourceId,targetId,side='before'){
  const source=items.findIndex(i=>i.id===sourceId),target=items.findIndex(i=>i.id===targetId);
  if(source<0||target<0||source===target)return items;
  let destination=target+(side==='after'?1:0);if(source<destination)destination--;
  if(destination===source)return items;
  const next=[...items],item=next.splice(source,1)[0];next.splice(destination,0,item);return next;
}
export function insertItemAfter(items,sourceId,item){
  if(items.some(i=>i.id===item.id))return items;
  const index=sourceId===null?items.length-1:items.findIndex(i=>i.id===sourceId);
  if(sourceId!==null&&index<0)return items;
  const next=[...items];next.splice(index+1,0,item);return next;
}
export function wantsNewItem(event,composing=false){
  return event.key==='Enter'&&event.shiftKey&&!event.ctrlKey&&!event.altKey&&!event.metaKey&&!event.repeat&&!event.isComposing&&!composing&&event.keyCode!==229;
}
