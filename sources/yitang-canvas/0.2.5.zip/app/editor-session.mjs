import {uid} from './model.mjs';
// One ordered save stream per open canvas. A response acknowledges only its own snapshot.
export class EditorSession{
  constructor({record,write,read,persist=()=>{},clear=()=>{},notify=()=>{},delay=600}){
    Object.assign(this,{record:structuredClone(record),saved:structuredClone(record),write,read,persist,clear,notify,delay,serial:0,dirty:false,status:'saved',error:'',conflict:null,timer:null,pending:null,disposed:false});
  }
  changed(){if(!this.disposed)this.notify(this);}
  remember(){try{this.persist({record:this.record,baseRevision:this.saved.revision});this.draftWarning='';}catch{this.draftWarning='浏览器无法保存恢复草稿，请保持窗口打开并保存或导出当前内容。';}}
  edit(action){this.record=action(structuredClone(this.record));this.serial++;this.dirty=true;this.status=this.conflict?'conflict':'unsaved';this.remember();this.changed();clearTimeout(this.timer);if(!this.conflict)this.timer=setTimeout(()=>void this.flush().catch(()=>{}),this.delay);}
  restore(draft){this.record=structuredClone(draft.record);this.dirty=true;this.serial++;if(draft.baseRevision!==this.saved.revision){this.conflict=this.saved;this.status='conflict';this.error='找到尚未保存的草稿，但已保存版本也发生了变化。';this.changed();}else{this.status='unsaved';this.changed();this.timer=setTimeout(()=>void this.flush().catch(()=>{}),this.delay);}}
  async flush(){
    clearTimeout(this.timer);if(this.conflict)throw Error(this.error||'请先处理版本冲突。');
    if(this.pending){await this.pending;if(this.dirty)return this.flush();return;}
    if(!this.dirty)return;
    const snapshot=structuredClone(this.record),serial=this.serial,operationId=uid();snapshot.revision=this.saved.revision;
    this.status='saving';this.error='';this.changed();
    this.pending=(async()=>{
      let next;
      try{next=await this.write({...snapshot,operationId});}
      catch(error){
        let remote;try{remote=await this.read(snapshot.id);}catch{}
        if(remote?.lastOperation?.id===operationId)next=remote;
        else{if(remote&&remote.revision!==this.saved.revision){this.conflict=remote;this.status='conflict';}else this.status='error';this.error='保存未完成，草稿已保留。'+(error.message||'请稍后重试。');this.remember();this.changed();throw error;}
      }
      this.saved=structuredClone(next);
      if(serial===this.serial){this.record=structuredClone(next);this.dirty=false;this.status='saved';try{this.clear();}catch{}}
      else{this.record.revision=next.revision;this.status='unsaved';this.remember();}
      this.changed();
    })();
    try{await this.pending;}finally{this.pending=null;}
    if(this.dirty)return this.flush();
  }
  useSaved(){this.record=structuredClone(this.conflict??this.saved);this.saved=structuredClone(this.record);this.dirty=false;this.error='';this.conflict=null;this.status='saved';try{this.clear();}catch{}this.changed();}
  dispose(){this.disposed=true;clearTimeout(this.timer);}
}
