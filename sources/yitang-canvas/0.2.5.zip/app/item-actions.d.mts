import type {Item} from './types';
export function reorderItems(items:Item[],sourceId:string,targetId:string,side?:'before'|'after'):Item[];
export function insertItemAfter(items:Item[],sourceId:string|null,item:Item):Item[];
export function wantsNewItem(event:{key:string;shiftKey?:boolean;ctrlKey?:boolean;altKey?:boolean;metaKey?:boolean;repeat?:boolean;isComposing?:boolean;keyCode?:number},composing?:boolean):boolean;
